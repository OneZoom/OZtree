$(function() {
  var taxa_list = ['gallus',
                   'thalurania',
                   'sphenisciformes',
                   'strigidae',
                   'falconiformes',
                   'psittaciformes',
                   'passeri',
                   'ptilonorhynchidae',
                   'furnariidae',
                   'paradisaeidae',
                   'petroicidae',
                   'passeridae',
                   'pheucticus',
                   'diglossa'];
	taxa_URL = taxa_list[Math.floor(Math.random() * taxa_list.length)];
});