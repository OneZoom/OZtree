$(function() {
  var taxa_list = ['pseudoeurycea',
                   'dendrotriton',
                   'nototriton',
                   'salamandridae',
                   'bombinatoridae',
                   'amphignathodontidae',
                   'centrolenidae',
                   'aromobatidae',
                   'melanophryniscus',
                   'bufonidae',
                   'pedostibes',
                   'myobatrachidae'];
	taxa_URL = taxa_list[Math.floor(Math.random() * taxa_list.length)];
});