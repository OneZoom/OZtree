$(function() {
  var taxa_list = ['macropodiformes',
                   'macroscelidea',
                   'cabassous',
                   'erinaceomorpha',
                   'felidae',
                   'ursidae',
                   'mustela',
                   'bovidae',
                   'cetacea',
                   'pteropodidae',
                   'vespertilionidae',
                   'primates',
                   'hominidae',
                   'ochotona',
                   'lepus',
                   'muroidea'];
	taxa_URL = taxa_list[Math.floor(Math.random() * taxa_list.length)];
});