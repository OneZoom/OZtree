$(function() {
  var taxa_list = [
'lamiaceae',
'cinnamomum',
'oleaceae',
'rubiaceae',
'ilex',
'theaceae',
'lecythidaceae',
'cactaceae',
'viscaceae',
'droseraceae',
'fabaceae',
'myristicaceae',
'orchidaceae',
'poaceae',
'musaceae'
];


	taxa_URL = taxa_list[Math.floor(Math.random() * taxa_list.length)];
});